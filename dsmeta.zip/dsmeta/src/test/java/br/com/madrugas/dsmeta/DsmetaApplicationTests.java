package br.com.madrugas.dsmeta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsmetaApplicationTests {

	@Test
	void contextLoads() {
	}

}
